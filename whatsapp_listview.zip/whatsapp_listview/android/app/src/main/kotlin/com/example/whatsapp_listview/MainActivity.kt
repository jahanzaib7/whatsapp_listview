package com.example.whatsapp_listview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
