import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget makeListTile(Text title,Text subtitle, Icon trailing, Widget avatar){
return Container(
  margin: EdgeInsets.only(bottom: 2),
child:  ListTile(

  tileColor: Colors.grey[200] ,
 leading:CircleAvatar(
   backgroundColor:Colors.red[200],
  
   radius: 20,
     ),
 
 title:title,
 subtitle:subtitle,
 trailing:trailing,
//  color: Colors.red,
));
}
