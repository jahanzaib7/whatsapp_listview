import 'package:flutter/material.dart';
import 'package:whatsapp_listview/listTile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
    
        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(title: 'Whatsapp'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
 
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
   
        title: Text(widget.title),
        
      ),
      body: Center(
      
        child: Column(
          
 children:<Widget>[
   makeListTile(const Text("Jahanzaib"), const Text("Bye"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.red,radius: 20,)),
   makeListTile(const Text("Malik Sahab"), const Text("Hello"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.green,radius: 20,)),
   makeListTile(const Text("Muzammil"), const Text("Hi"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.red,radius: 20,)),
   makeListTile(const Text("Saad"), const Text("Bye"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.red,radius: 20,)),
   makeListTile(const Text("Maha"), const Text("Hey"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.red,radius: 20,)),
   makeListTile(const Text("Bilal"), const Text("Bye"), Icon(Icons.done_all), const CircleAvatar(backgroundColor: Colors.red,radius: 20,)),
   

 
  ]
        ),
        
      ),
      
    // This trailing comma makes auto-formatting nicer for build methods.
    );
    
  }
}
